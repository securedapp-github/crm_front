import { d as setEnabled, g as __toESM, l as setConsentStatus, m as require_browser_polyfill } from "../../storage.js";
//#region src/consent/main.ts
var import_browser_polyfill = /* @__PURE__ */ __toESM(require_browser_polyfill(), 1);
document.getElementById("consent-refused").addEventListener("click", () => {
	import_browser_polyfill.default.management.uninstallSelf();
	window.close();
});
document.getElementById("consent-given").addEventListener("click", async () => {
	await setConsentStatus({
		consent: true,
		required: true
	});
	await setEnabled(true);
	window.close();
});
//#endregion
