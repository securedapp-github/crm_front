(function() {
	//#region \0rolldown/runtime.js
	var __create = Object.create;
	var __defProp = Object.defineProperty;
	var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
	var __getOwnPropNames = Object.getOwnPropertyNames;
	var __getProtoOf = Object.getPrototypeOf;
	var __hasOwnProp = Object.prototype.hasOwnProperty;
	var __commonJSMin = (cb, mod) => () => (mod || (cb((mod = { exports: {} }).exports, mod), cb = null), mod.exports);
	var __copyProps = (to, from, except, desc) => {
		if (from && typeof from === "object" || typeof from === "function") for (var keys = __getOwnPropNames(from), i = 0, n = keys.length, key; i < n; i++) {
			key = keys[i];
			if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
				get: ((k) => from[k]).bind(null, key),
				enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
			});
		}
		return to;
	};
	var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", {
		value: mod,
		enumerable: true
	}) : target, mod));
	//#endregion
	//#region src/config.ts
	var import_browser_polyfill = /* @__PURE__ */ __toESM((/* @__PURE__ */ __commonJSMin(((exports, module) => {
		(function(global, factory) {
			if (typeof define === "function" && define.amd) define("webextension-polyfill", ["module"], factory);
			else if (typeof exports !== "undefined") factory(module);
			else {
				var mod = { exports: {} };
				factory(mod);
				global.browser = mod.exports;
			}
		})(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports, function(module$1) {
			"use strict";
			if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) throw new Error("This script should only be loaded in a browser extension.");
			if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
				const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
				const wrapAPIs = (extensionAPIs) => {
					const apiMetadata = {
						"alarms": {
							"clear": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"clearAll": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"get": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"getAll": {
								"minArgs": 0,
								"maxArgs": 0
							}
						},
						"bookmarks": {
							"create": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"get": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getChildren": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getRecent": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getSubTree": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getTree": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"move": {
								"minArgs": 2,
								"maxArgs": 2
							},
							"remove": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"removeTree": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"search": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"update": {
								"minArgs": 2,
								"maxArgs": 2
							}
						},
						"browserAction": {
							"disable": {
								"minArgs": 0,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							},
							"enable": {
								"minArgs": 0,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							},
							"getBadgeBackgroundColor": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getBadgeText": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getPopup": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getTitle": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"openPopup": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"setBadgeBackgroundColor": {
								"minArgs": 1,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							},
							"setBadgeText": {
								"minArgs": 1,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							},
							"setIcon": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"setPopup": {
								"minArgs": 1,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							},
							"setTitle": {
								"minArgs": 1,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							}
						},
						"browsingData": {
							"remove": {
								"minArgs": 2,
								"maxArgs": 2
							},
							"removeCache": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"removeCookies": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"removeDownloads": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"removeFormData": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"removeHistory": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"removeLocalStorage": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"removePasswords": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"removePluginData": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"settings": {
								"minArgs": 0,
								"maxArgs": 0
							}
						},
						"commands": { "getAll": {
							"minArgs": 0,
							"maxArgs": 0
						} },
						"contextMenus": {
							"remove": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"removeAll": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"update": {
								"minArgs": 2,
								"maxArgs": 2
							}
						},
						"cookies": {
							"get": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getAll": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getAllCookieStores": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"remove": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"set": {
								"minArgs": 1,
								"maxArgs": 1
							}
						},
						"devtools": {
							"inspectedWindow": { "eval": {
								"minArgs": 1,
								"maxArgs": 2,
								"singleCallbackArg": false
							} },
							"panels": {
								"create": {
									"minArgs": 3,
									"maxArgs": 3,
									"singleCallbackArg": true
								},
								"elements": { "createSidebarPane": {
									"minArgs": 1,
									"maxArgs": 1
								} }
							}
						},
						"downloads": {
							"cancel": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"download": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"erase": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getFileIcon": {
								"minArgs": 1,
								"maxArgs": 2
							},
							"open": {
								"minArgs": 1,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							},
							"pause": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"removeFile": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"resume": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"search": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"show": {
								"minArgs": 1,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							}
						},
						"extension": {
							"isAllowedFileSchemeAccess": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"isAllowedIncognitoAccess": {
								"minArgs": 0,
								"maxArgs": 0
							}
						},
						"history": {
							"addUrl": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"deleteAll": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"deleteRange": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"deleteUrl": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getVisits": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"search": {
								"minArgs": 1,
								"maxArgs": 1
							}
						},
						"i18n": {
							"detectLanguage": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getAcceptLanguages": {
								"minArgs": 0,
								"maxArgs": 0
							}
						},
						"identity": { "launchWebAuthFlow": {
							"minArgs": 1,
							"maxArgs": 1
						} },
						"idle": { "queryState": {
							"minArgs": 1,
							"maxArgs": 1
						} },
						"management": {
							"get": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getAll": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"getSelf": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"setEnabled": {
								"minArgs": 2,
								"maxArgs": 2
							},
							"uninstallSelf": {
								"minArgs": 0,
								"maxArgs": 1
							}
						},
						"notifications": {
							"clear": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"create": {
								"minArgs": 1,
								"maxArgs": 2
							},
							"getAll": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"getPermissionLevel": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"update": {
								"minArgs": 2,
								"maxArgs": 2
							}
						},
						"pageAction": {
							"getPopup": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getTitle": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"hide": {
								"minArgs": 1,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							},
							"setIcon": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"setPopup": {
								"minArgs": 1,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							},
							"setTitle": {
								"minArgs": 1,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							},
							"show": {
								"minArgs": 1,
								"maxArgs": 1,
								"fallbackToNoCallback": true
							}
						},
						"permissions": {
							"contains": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getAll": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"remove": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"request": {
								"minArgs": 1,
								"maxArgs": 1
							}
						},
						"runtime": {
							"getBackgroundPage": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"getPlatformInfo": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"openOptionsPage": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"requestUpdateCheck": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"sendMessage": {
								"minArgs": 1,
								"maxArgs": 3
							},
							"sendNativeMessage": {
								"minArgs": 2,
								"maxArgs": 2
							},
							"setUninstallURL": {
								"minArgs": 1,
								"maxArgs": 1
							}
						},
						"sessions": {
							"getDevices": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"getRecentlyClosed": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"restore": {
								"minArgs": 0,
								"maxArgs": 1
							}
						},
						"storage": {
							"local": {
								"clear": {
									"minArgs": 0,
									"maxArgs": 0
								},
								"get": {
									"minArgs": 0,
									"maxArgs": 1
								},
								"getBytesInUse": {
									"minArgs": 0,
									"maxArgs": 1
								},
								"remove": {
									"minArgs": 1,
									"maxArgs": 1
								},
								"set": {
									"minArgs": 1,
									"maxArgs": 1
								}
							},
							"managed": {
								"get": {
									"minArgs": 0,
									"maxArgs": 1
								},
								"getBytesInUse": {
									"minArgs": 0,
									"maxArgs": 1
								}
							},
							"sync": {
								"clear": {
									"minArgs": 0,
									"maxArgs": 0
								},
								"get": {
									"minArgs": 0,
									"maxArgs": 1
								},
								"getBytesInUse": {
									"minArgs": 0,
									"maxArgs": 1
								},
								"remove": {
									"minArgs": 1,
									"maxArgs": 1
								},
								"set": {
									"minArgs": 1,
									"maxArgs": 1
								}
							}
						},
						"tabs": {
							"captureVisibleTab": {
								"minArgs": 0,
								"maxArgs": 2
							},
							"create": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"detectLanguage": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"discard": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"duplicate": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"executeScript": {
								"minArgs": 1,
								"maxArgs": 2
							},
							"get": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getCurrent": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"getZoom": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"getZoomSettings": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"goBack": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"goForward": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"highlight": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"insertCSS": {
								"minArgs": 1,
								"maxArgs": 2
							},
							"move": {
								"minArgs": 2,
								"maxArgs": 2
							},
							"query": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"reload": {
								"minArgs": 0,
								"maxArgs": 2
							},
							"remove": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"removeCSS": {
								"minArgs": 1,
								"maxArgs": 2
							},
							"sendMessage": {
								"minArgs": 2,
								"maxArgs": 3
							},
							"setZoom": {
								"minArgs": 1,
								"maxArgs": 2
							},
							"setZoomSettings": {
								"minArgs": 1,
								"maxArgs": 2
							},
							"update": {
								"minArgs": 1,
								"maxArgs": 2
							}
						},
						"topSites": { "get": {
							"minArgs": 0,
							"maxArgs": 0
						} },
						"webNavigation": {
							"getAllFrames": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"getFrame": {
								"minArgs": 1,
								"maxArgs": 1
							}
						},
						"webRequest": { "handlerBehaviorChanged": {
							"minArgs": 0,
							"maxArgs": 0
						} },
						"windows": {
							"create": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"get": {
								"minArgs": 1,
								"maxArgs": 2
							},
							"getAll": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"getCurrent": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"getLastFocused": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"remove": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"update": {
								"minArgs": 2,
								"maxArgs": 2
							}
						}
					};
					if (Object.keys(apiMetadata).length === 0) throw new Error("api-metadata.json has not been included in browser-polyfill");
					/**
					* A WeakMap subclass which creates and stores a value for any key which does
					* not exist when accessed, but behaves exactly as an ordinary WeakMap
					* otherwise.
					*
					* @param {function} createItem
					*        A function which will be called in order to create the value for any
					*        key which does not exist, the first time it is accessed. The
					*        function receives, as its only argument, the key being created.
					*/
					class DefaultWeakMap extends WeakMap {
						constructor(createItem, items = void 0) {
							super(items);
							this.createItem = createItem;
						}
						get(key) {
							if (!this.has(key)) this.set(key, this.createItem(key));
							return super.get(key);
						}
					}
					/**
					* Returns true if the given object is an object with a `then` method, and can
					* therefore be assumed to behave as a Promise.
					*
					* @param {*} value The value to test.
					* @returns {boolean} True if the value is thenable.
					*/
					const isThenable = (value) => {
						return value && typeof value === "object" && typeof value.then === "function";
					};
					/**
					* Creates and returns a function which, when called, will resolve or reject
					* the given promise based on how it is called:
					*
					* - If, when called, `chrome.runtime.lastError` contains a non-null object,
					*   the promise is rejected with that value.
					* - If the function is called with exactly one argument, the promise is
					*   resolved to that value.
					* - Otherwise, the promise is resolved to an array containing all of the
					*   function's arguments.
					*
					* @param {object} promise
					*        An object containing the resolution and rejection functions of a
					*        promise.
					* @param {function} promise.resolve
					*        The promise's resolution function.
					* @param {function} promise.reject
					*        The promise's rejection function.
					* @param {object} metadata
					*        Metadata about the wrapped method which has created the callback.
					* @param {boolean} metadata.singleCallbackArg
					*        Whether or not the promise is resolved with only the first
					*        argument of the callback, alternatively an array of all the
					*        callback arguments is resolved. By default, if the callback
					*        function is invoked with only a single argument, that will be
					*        resolved to the promise, while all arguments will be resolved as
					*        an array if multiple are given.
					*
					* @returns {function}
					*        The generated callback function.
					*/
					const makeCallback = (promise, metadata) => {
						return (...callbackArgs) => {
							if (extensionAPIs.runtime.lastError) promise.reject(new Error(extensionAPIs.runtime.lastError.message));
							else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) promise.resolve(callbackArgs[0]);
							else promise.resolve(callbackArgs);
						};
					};
					const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
					/**
					* Creates a wrapper function for a method with the given name and metadata.
					*
					* @param {string} name
					*        The name of the method which is being wrapped.
					* @param {object} metadata
					*        Metadata about the method being wrapped.
					* @param {integer} metadata.minArgs
					*        The minimum number of arguments which must be passed to the
					*        function. If called with fewer than this number of arguments, the
					*        wrapper will raise an exception.
					* @param {integer} metadata.maxArgs
					*        The maximum number of arguments which may be passed to the
					*        function. If called with more than this number of arguments, the
					*        wrapper will raise an exception.
					* @param {boolean} metadata.singleCallbackArg
					*        Whether or not the promise is resolved with only the first
					*        argument of the callback, alternatively an array of all the
					*        callback arguments is resolved. By default, if the callback
					*        function is invoked with only a single argument, that will be
					*        resolved to the promise, while all arguments will be resolved as
					*        an array if multiple are given.
					*
					* @returns {function(object, ...*)}
					*       The generated wrapper function.
					*/
					const wrapAsyncFunction = (name, metadata) => {
						return function asyncFunctionWrapper(target, ...args) {
							if (args.length < metadata.minArgs) throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
							if (args.length > metadata.maxArgs) throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
							return new Promise((resolve, reject) => {
								if (metadata.fallbackToNoCallback) try {
									target[name](...args, makeCallback({
										resolve,
										reject
									}, metadata));
								} catch (cbError) {
									console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
									target[name](...args);
									metadata.fallbackToNoCallback = false;
									metadata.noCallback = true;
									resolve();
								}
								else if (metadata.noCallback) {
									target[name](...args);
									resolve();
								} else target[name](...args, makeCallback({
									resolve,
									reject
								}, metadata));
							});
						};
					};
					/**
					* Wraps an existing method of the target object, so that calls to it are
					* intercepted by the given wrapper function. The wrapper function receives,
					* as its first argument, the original `target` object, followed by each of
					* the arguments passed to the original method.
					*
					* @param {object} target
					*        The original target object that the wrapped method belongs to.
					* @param {function} method
					*        The method being wrapped. This is used as the target of the Proxy
					*        object which is created to wrap the method.
					* @param {function} wrapper
					*        The wrapper function which is called in place of a direct invocation
					*        of the wrapped method.
					*
					* @returns {Proxy<function>}
					*        A Proxy object for the given method, which invokes the given wrapper
					*        method in its place.
					*/
					const wrapMethod = (target, method, wrapper) => {
						return new Proxy(method, { apply(targetMethod, thisObj, args) {
							return wrapper.call(thisObj, target, ...args);
						} });
					};
					let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
					/**
					* Wraps an object in a Proxy which intercepts and wraps certain methods
					* based on the given `wrappers` and `metadata` objects.
					*
					* @param {object} target
					*        The target object to wrap.
					*
					* @param {object} [wrappers = {}]
					*        An object tree containing wrapper functions for special cases. Any
					*        function present in this object tree is called in place of the
					*        method in the same location in the `target` object tree. These
					*        wrapper methods are invoked as described in {@see wrapMethod}.
					*
					* @param {object} [metadata = {}]
					*        An object tree containing metadata used to automatically generate
					*        Promise-based wrapper functions for asynchronous. Any function in
					*        the `target` object tree which has a corresponding metadata object
					*        in the same location in the `metadata` tree is replaced with an
					*        automatically-generated wrapper function, as described in
					*        {@see wrapAsyncFunction}
					*
					* @returns {Proxy<object>}
					*/
					const wrapObject = (target, wrappers = {}, metadata = {}) => {
						let cache = Object.create(null);
						return new Proxy(Object.create(target), {
							has(proxyTarget, prop) {
								return prop in target || prop in cache;
							},
							get(proxyTarget, prop, receiver) {
								if (prop in cache) return cache[prop];
								if (!(prop in target)) return;
								let value = target[prop];
								if (typeof value === "function") if (typeof wrappers[prop] === "function") value = wrapMethod(target, target[prop], wrappers[prop]);
								else if (hasOwnProperty(metadata, prop)) {
									let wrapper = wrapAsyncFunction(prop, metadata[prop]);
									value = wrapMethod(target, target[prop], wrapper);
								} else value = value.bind(target);
								else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) value = wrapObject(value, wrappers[prop], metadata[prop]);
								else if (hasOwnProperty(metadata, "*")) value = wrapObject(value, wrappers[prop], metadata["*"]);
								else {
									Object.defineProperty(cache, prop, {
										configurable: true,
										enumerable: true,
										get() {
											return target[prop];
										},
										set(value) {
											target[prop] = value;
										}
									});
									return value;
								}
								cache[prop] = value;
								return value;
							},
							set(proxyTarget, prop, value, receiver) {
								if (prop in cache) cache[prop] = value;
								else target[prop] = value;
								return true;
							},
							defineProperty(proxyTarget, prop, desc) {
								return Reflect.defineProperty(cache, prop, desc);
							},
							deleteProperty(proxyTarget, prop) {
								return Reflect.deleteProperty(cache, prop);
							}
						});
					};
					/**
					* Creates a set of wrapper functions for an event object, which handles
					* wrapping of listener functions that those messages are passed.
					*
					* A single wrapper is created for each listener function, and stored in a
					* map. Subsequent calls to `addListener`, `hasListener`, or `removeListener`
					* retrieve the original wrapper, so that  attempts to remove a
					* previously-added listener work as expected.
					*
					* @param {DefaultWeakMap<function, function>} wrapperMap
					*        A DefaultWeakMap object which will create the appropriate wrapper
					*        for a given listener function when one does not exist, and retrieve
					*        an existing one when it does.
					*
					* @returns {object}
					*/
					const wrapEvent = (wrapperMap) => ({
						addListener(target, listener, ...args) {
							target.addListener(wrapperMap.get(listener), ...args);
						},
						hasListener(target, listener) {
							return target.hasListener(wrapperMap.get(listener));
						},
						removeListener(target, listener) {
							target.removeListener(wrapperMap.get(listener));
						}
					});
					const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
						if (typeof listener !== "function") return listener;
						/**
						* Wraps an onRequestFinished listener function so that it will return a
						* `getContent()` property which returns a `Promise` rather than using a
						* callback API.
						*
						* @param {object} req
						*        The HAR entry object representing the network request.
						*/
						return function onRequestFinished(req) {
							listener(wrapObject(req, {}, { getContent: {
								minArgs: 0,
								maxArgs: 0
							} }));
						};
					});
					const onMessageWrappers = new DefaultWeakMap((listener) => {
						if (typeof listener !== "function") return listener;
						/**
						* Wraps a message listener function so that it may send responses based on
						* its return value, rather than by returning a sentinel value and calling a
						* callback. If the listener function returns a Promise, the response is
						* sent when the promise either resolves or rejects.
						*
						* @param {*} message
						*        The message sent by the other end of the channel.
						* @param {object} sender
						*        Details about the sender of the message.
						* @param {function(*)} sendResponse
						*        A callback which, when called with an arbitrary argument, sends
						*        that value as a response.
						* @returns {boolean}
						*        True if the wrapped listener returned a Promise, which will later
						*        yield a response. False otherwise.
						*/
						return function onMessage(message, sender, sendResponse) {
							let didCallSendResponse = false;
							let wrappedSendResponse;
							let sendResponsePromise = new Promise((resolve) => {
								wrappedSendResponse = function(response) {
									didCallSendResponse = true;
									resolve(response);
								};
							});
							let result;
							try {
								result = listener(message, sender, wrappedSendResponse);
							} catch (err) {
								result = Promise.reject(err);
							}
							const isResultThenable = result !== true && isThenable(result);
							if (result !== true && !isResultThenable && !didCallSendResponse) return false;
							const sendPromisedResult = (promise) => {
								promise.then((msg) => {
									sendResponse(msg);
								}, (error) => {
									let message;
									if (error && (error instanceof Error || typeof error.message === "string")) message = error.message;
									else message = "An unexpected error occurred";
									sendResponse({
										__mozWebExtensionPolyfillReject__: true,
										message
									});
								}).catch((err) => {
									console.error("Failed to send onMessage rejected reply", err);
								});
							};
							if (isResultThenable) sendPromisedResult(result);
							else sendPromisedResult(sendResponsePromise);
							return true;
						};
					});
					const wrappedSendMessageCallback = ({ reject, resolve }, reply) => {
						if (extensionAPIs.runtime.lastError) if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) resolve();
						else reject(new Error(extensionAPIs.runtime.lastError.message));
						else if (reply && reply.__mozWebExtensionPolyfillReject__) reject(new Error(reply.message));
						else resolve(reply);
					};
					const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
						if (args.length < metadata.minArgs) throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
						if (args.length > metadata.maxArgs) throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
						return new Promise((resolve, reject) => {
							const wrappedCb = wrappedSendMessageCallback.bind(null, {
								resolve,
								reject
							});
							args.push(wrappedCb);
							apiNamespaceObj.sendMessage(...args);
						});
					};
					const staticWrappers = {
						devtools: { network: { onRequestFinished: wrapEvent(onRequestFinishedWrappers) } },
						runtime: {
							onMessage: wrapEvent(onMessageWrappers),
							onMessageExternal: wrapEvent(onMessageWrappers),
							sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
								minArgs: 1,
								maxArgs: 3
							})
						},
						tabs: { sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
							minArgs: 2,
							maxArgs: 3
						}) }
					};
					const settingMetadata = {
						clear: {
							minArgs: 1,
							maxArgs: 1
						},
						get: {
							minArgs: 1,
							maxArgs: 1
						},
						set: {
							minArgs: 1,
							maxArgs: 1
						}
					};
					apiMetadata.privacy = {
						network: { "*": settingMetadata },
						services: { "*": settingMetadata },
						websites: { "*": settingMetadata }
					};
					return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
				};
				module$1.exports = wrapAPIs(chrome);
			} else module$1.exports = globalThis.browser;
		});
	})))(), 1);
	var config = {
		isDevelopment: false,
		requireConsent: false,
		heartbeat: {
			alarmName: "heartbeat",
			intervalInSeconds: 60
		}
	};
	//#endregion
	//#region src/storage.ts
	var import_aw_client = (/* @__PURE__ */ __commonJSMin(((exports) => {
		var __awaiter = exports && exports.__awaiter || function(thisArg, _arguments, P, generator) {
			function adopt(value) {
				return value instanceof P ? value : new P(function(resolve) {
					resolve(value);
				});
			}
			return new (P || (P = Promise))(function(resolve, reject) {
				function fulfilled(value) {
					try {
						step(generator.next(value));
					} catch (e) {
						reject(e);
					}
				}
				function rejected(value) {
					try {
						step(generator["throw"](value));
					} catch (e) {
						reject(e);
					}
				}
				function step(result) {
					result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
				}
				step((generator = generator.apply(thisArg, _arguments || [])).next());
			});
		};
		Object.defineProperty(exports, "__esModule", { value: true });
		exports.AWClient = exports.FetchError = void 0;
		var FetchError = class extends Error {
			constructor(res) {
				super(`Failed fetch with status code ${res.status}`);
				this.response = res;
			}
		};
		exports.FetchError = FetchError;
		function makeTimeoutAbortSignal(timeout, existingSignal) {
			if (timeout === void 0) return {
				signal: existingSignal,
				timeoutId: void 0
			};
			const abortController = new AbortController();
			const timeoutId = setTimeout(() => abortController.abort(), timeout || 1e4);
			if (existingSignal === null || existingSignal === void 0 ? void 0 : existingSignal.aborted) abortController.abort();
			else existingSignal === null || existingSignal === void 0 || existingSignal.addEventListener("abort", () => abortController.abort());
			return {
				signal: abortController.signal,
				timeoutId
			};
		}
		function fetchWithFailure(input, init, timeout) {
			return __awaiter(this, void 0, void 0, function* () {
				const { signal, timeoutId } = makeTimeoutAbortSignal(timeout, init.signal || void 0);
				return fetch(input, Object.assign(Object.assign({}, init), { signal })).then((res) => {
					if (res.status >= 300) throw new FetchError(res);
					return res;
				}).finally(() => clearTimeout(timeoutId));
			});
		}
		var AWClient = class {
			constructor(clientname, options = {}) {
				var _a, _b;
				this.heartbeatQueues = {};
				this.clientname = clientname;
				this.testing = (_a = options.testing) !== null && _a !== void 0 ? _a : false;
				this.timeout = (_b = options.timeout) !== null && _b !== void 0 ? _b : 3e4;
				if (typeof options.baseURL === "undefined") {
					const port = !options.testing ? 5600 : 5666;
					this.baseURL = `http://127.0.0.1:${port}`;
				} else this.baseURL = options.baseURL;
				this.apiURL = this.baseURL + "/api";
				this.controller = options.controller || new AbortController();
				this.queryCache = {};
			}
			/** Makes a GET request, assuming the response is JSON and parsing it */
			_get(endpoint_1) {
				return __awaiter(this, arguments, void 0, function* (endpoint, params = {}) {
					return fetchWithFailure(`${this.apiURL}${endpoint}`, Object.assign(Object.assign({}, params), { signal: this.controller.signal }), this.timeout).then((res) => res.json());
				});
			}
			_post(endpoint, data) {
				return __awaiter(this, void 0, void 0, function* () {
					return fetchWithFailure(`${this.apiURL}${endpoint}`, {
						method: "POST",
						signal: this.controller.signal,
						headers: { "Content-Type": "application/json" },
						body: JSON.stringify(data)
					}, this.timeout);
				});
			}
			_delete(endpoint) {
				return __awaiter(this, void 0, void 0, function* () {
					return fetchWithFailure(`${this.apiURL}${endpoint}`, {
						method: "DELETE",
						signal: this.controller.signal
					}, this.timeout);
				});
			}
			getInfo() {
				return __awaiter(this, void 0, void 0, function* () {
					return this._get("/0/info");
				});
			}
			abort(msg) {
				return __awaiter(this, void 0, void 0, function* () {
					console.info(msg || "Requests cancelled");
					this.controller.abort();
					this.controller = new AbortController();
				});
			}
			processRawBucket(bucket) {
				return Object.assign(Object.assign({}, bucket), {
					created: new Date(bucket.created),
					last_update: bucket.last_update !== void 0 ? new Date(bucket.last_update) : void 0
				});
			}
			ensureBucket(bucketId, type, hostname) {
				return __awaiter(this, void 0, void 0, function* () {
					return this._post(`/0/buckets/${bucketId}`, {
						client: this.clientname,
						type,
						hostname
					}).then(() => ({ alreadyExist: false })).catch((err) => {
						if (err instanceof FetchError && err.response.status === 304) return { alreadyExist: true };
						throw err;
					});
				});
			}
			createBucket(bucketId, type, hostname) {
				return __awaiter(this, void 0, void 0, function* () {
					yield this._post(`/0/buckets/${bucketId}`, {
						client: this.clientname,
						type,
						hostname
					});
				});
			}
			deleteBucket(bucketId) {
				return __awaiter(this, void 0, void 0, function* () {
					yield this._delete(`/0/buckets/${bucketId}?force=1`);
				});
			}
			getBuckets() {
				return __awaiter(this, void 0, void 0, function* () {
					const rawBuckets = yield this._get("/0/buckets/");
					const buckets = {};
					for (const bucketId of Object.keys(rawBuckets)) buckets[bucketId] = this.processRawBucket(rawBuckets[bucketId]);
					return buckets;
				});
			}
			getBucketInfo(bucketId) {
				return __awaiter(this, void 0, void 0, function* () {
					const bucket = yield this._get(`/0/buckets/${bucketId}`);
					if (bucket.data === void 0) {
						console.warn("Received bucket had undefined data, likely due to data field unsupported by server. Try updating your ActivityWatch server to get rid of this message.");
						bucket.data = {};
					}
					return this.processRawBucket(bucket);
				});
			}
			processRawEvent(event) {
				return Object.assign(Object.assign({}, event), { timestamp: new Date(event.timestamp) });
			}
			/** Get a single event by ID */
			getEvent(bucketId, eventId) {
				return __awaiter(this, void 0, void 0, function* () {
					return this._get(`/0/buckets/${bucketId}/events/${eventId}`).then(this.processRawEvent);
				});
			}
			/** Get events, with optional date ranges and limit */
			getEvents(bucketId_1) {
				return __awaiter(this, arguments, void 0, function* (bucketId, params = {}) {
					const searchParams = new URLSearchParams();
					if (params.start) searchParams.set("start", params.start.toISOString());
					if (params.end) searchParams.set("end", params.end.toISOString());
					if (params.limit) searchParams.set("limit", params.limit.toString());
					const url = `/0/buckets/${bucketId}/events?${searchParams.toString()}`;
					return this._get(url).then((events) => events.map(this.processRawEvent));
				});
			}
			/** Count the number of events, with optional date ranges */
			countEvents(bucketId, startTime, endTime) {
				return __awaiter(this, void 0, void 0, function* () {
					const params = new URLSearchParams();
					if (startTime) params.set("start", startTime.toISOString());
					if (endTime) params.set("end", endTime.toISOString());
					const url = `/0/buckets/${bucketId}/events/count?${params.toString()}`;
					return this._get(url);
				});
			}
			/** Insert a single event, requires the event to not have an ID assigned */
			insertEvent(bucketId, event) {
				return __awaiter(this, void 0, void 0, function* () {
					yield this.insertEvents(bucketId, [event]);
				});
			}
			/** Insert multiple events, requires the events to not have IDs assigned */
			insertEvents(bucketId, events) {
				return __awaiter(this, void 0, void 0, function* () {
					for (const event of events) if (event.id !== void 0) throw Error(`Can't insert event with ID assigned: ${event}`);
					yield this._post("/0/buckets/" + bucketId + "/events", events);
				});
			}
			/** Replace an event, requires the event to have an ID assigned */
			replaceEvent(bucketId, event) {
				return __awaiter(this, void 0, void 0, function* () {
					yield this.replaceEvents(bucketId, [event]);
				});
			}
			/** Replace multiple events, requires the events to have IDs assigned */
			replaceEvents(bucketId, events) {
				return __awaiter(this, void 0, void 0, function* () {
					for (const event of events) if (event.id === void 0) throw Error("Can't replace event without ID assigned");
					yield this._post("/0/buckets/" + bucketId + "/events", events);
				});
			}
			/** Delete an event by ID */
			deleteEvent(bucketId, eventId) {
				return __awaiter(this, void 0, void 0, function* () {
					yield this._delete("/0/buckets/" + bucketId + "/events/" + eventId);
				});
			}
			/**
			* @param bucketId The id of the bucket to send the heartbeat to
			* @param pulsetime The maximum amount of time in seconds since the last heartbeat to be merged
			*                  with the previous heartbeat in aw-server
			* @param heartbeat The actual heartbeat event
			*/
			heartbeat(bucketId, pulsetime, heartbeat) {
				var _a;
				var _b;
				(_a = (_b = this.heartbeatQueues)[bucketId]) !== null && _a !== void 0 || (_b[bucketId] = {
					isProcessing: false,
					data: []
				});
				return new Promise((resolve, reject) => {
					this.heartbeatQueues[bucketId].data.push({
						onSuccess: resolve,
						onError: reject,
						pulsetime,
						heartbeat
					});
					this.updateHeartbeatQueue(bucketId);
				});
			}
			/**
			* Queries the aw-server for data
			*
			* If cache is enabled, for each {query, timeperiod} it will return cached data if available,
			* if a timeperiod spans the future it will not cache it.
			*/
			query(timeperiods_1, query_1) {
				return __awaiter(this, arguments, void 0, function* (timeperiods, query, params = {}) {
					var _a, _b, _c, _d;
					params.cache = (_a = params.cache) !== null && _a !== void 0 ? _a : true;
					params.cacheEmpty = (_b = params.cacheEmpty) !== null && _b !== void 0 ? _b : false;
					params.verbose = (_c = params.verbose) !== null && _c !== void 0 ? _c : false;
					params.name = (_d = params.name) !== null && _d !== void 0 ? _d : "query";
					function isEmpty(obj) {
						return Object.keys(obj).length === 0;
					}
					const data = {
						query,
						timeperiods: timeperiods.map((tp) => typeof tp !== "string" ? `${tp.start.toISOString()}/${tp.end.toISOString()}` : tp)
					};
					const cacheResults = [];
					if (params.cache) {
						for (const timeperiod of data.timeperiods) {
							const stop = new Date(timeperiod.split("/")[1]);
							if (/* @__PURE__ */ new Date() < stop) {
								cacheResults.push(null);
								continue;
							}
							const cacheKey = JSON.stringify({
								timeperiod,
								query
							});
							if (this.queryCache[cacheKey] && (params.cacheEmpty || !isEmpty(this.queryCache[cacheKey]))) cacheResults.push(this.queryCache[cacheKey]);
							else cacheResults.push(null);
						}
						if (cacheResults.every((r) => r !== null)) {
							if (params.verbose) console.debug(`Returning fully cached query results for ${params.name}`);
							return cacheResults;
						}
					}
					const timeperiodsNotCached = data.timeperiods.filter((_, i) => cacheResults[i] === null);
					const queryResults = timeperiodsNotCached.length > 0 ? yield this._post("/0/query/", Object.assign(Object.assign({}, data), { timeperiods: timeperiodsNotCached })).then((res) => res.json()) : [];
					if (!params.cache) return queryResults;
					if (params.verbose) {
						if (cacheResults.every((r) => r === null)) console.debug(`Returning uncached query results for ${params.name}`);
						else if (cacheResults.some((r) => r === null) && cacheResults.some((r) => r !== null)) console.debug(`Returning partially cached query results for ${params.name}`);
					}
					for (const [i, result] of queryResults.entries()) {
						const cacheKey = JSON.stringify({
							timeperiod: timeperiodsNotCached[i],
							query
						});
						this.queryCache[cacheKey] = result;
					}
					return data.timeperiods.map((tp) => {
						const cacheKey = JSON.stringify({
							timeperiod: tp,
							query
						});
						return this.queryCache[cacheKey];
					});
				});
			}
			send_heartbeat(bucketId, pulsetime, data) {
				return __awaiter(this, void 0, void 0, function* () {
					const url = "/0/buckets/" + bucketId + "/heartbeat?pulsetime=" + pulsetime;
					const heartbeat = yield this._post(url, data).then((res) => res.json());
					heartbeat.timestamp = new Date(heartbeat.timestamp);
					return heartbeat;
				});
			}
			/** Start heartbeat queue processing if not currently processing */
			updateHeartbeatQueue(bucketId) {
				const queue = this.heartbeatQueues[bucketId];
				if (queue.isProcessing || !queue.data.length) return;
				const { pulsetime, heartbeat, onSuccess, onError } = queue.data.shift();
				queue.isProcessing = true;
				this.send_heartbeat(bucketId, pulsetime, heartbeat).then(() => {
					onSuccess();
					queue.isProcessing = false;
					this.updateHeartbeatQueue(bucketId);
				}).catch((err) => {
					onError(err);
					queue.isProcessing = false;
					this.updateHeartbeatQueue(bucketId);
				});
			}
			get_settings() {
				return __awaiter(this, void 0, void 0, function* () {
					return yield this._get("/0/settings");
				});
			}
			get_setting(key) {
				return __awaiter(this, void 0, void 0, function* () {
					return yield this._get("/0/settings/" + key);
				});
			}
			set_setting(key, value) {
				return __awaiter(this, void 0, void 0, function* () {
					yield this._post("/0/settings/" + key, value);
				});
			}
		};
		exports.AWClient = AWClient;
	})))();
	function watchKey(key, cb) {
		const listener = (changes) => {
			if (!(key in changes)) return;
			cb(changes[key].newValue);
		};
		import_browser_polyfill.default.storage.local.onChanged.addListener(listener);
		return () => import_browser_polyfill.default.storage.local.onChanged.removeListener(listener);
	}
	async function waitForKey(key, desiredValue) {
		if (await import_browser_polyfill.default.storage.local.get(key).then((_) => _[key]) === desiredValue) return;
		return new Promise((resolve) => {
			const unsubscribe = watchKey(key, (value) => {
				if (value !== desiredValue) return;
				resolve();
				unsubscribe();
			});
		});
	}
	var getConsentStatus = async () => import_browser_polyfill.default.storage.local.get(["consentRequired", "consent"]).then(({ consent, consentRequired }) => ({
		consent: typeof consent === "boolean" ? consent : void 0,
		required: typeof consentRequired === "boolean" ? consentRequired : void 0
	}));
	var setConsentStatus = async (status) => import_browser_polyfill.default.storage.local.set({
		consentRequired: status.required,
		consent: status.consent
	});
	var waitForEnabled = () => waitForKey("enabled", true);
	var getEnabled = () => import_browser_polyfill.default.storage.local.get("enabled").then((_) => _.enabled === void 0 ? true : Boolean(_.enabled));
	var setEnabled = (enabled) => import_browser_polyfill.default.storage.local.set({ enabled });
	var setBaseUrl = (baseUrl) => import_browser_polyfill.default.storage.local.set({ baseUrl });
	var getBrowserName = () => import_browser_polyfill.default.storage.local.get("browserName").then((data) => data.browserName);
	var setBrowserName = (browserName) => import_browser_polyfill.default.storage.local.set({ browserName });
	var getHostname = () => import_browser_polyfill.default.storage.local.get("hostname").then((data) => data.hostname);
	var setHostname = (hostname) => import_browser_polyfill.default.storage.local.set({ hostname });
	var getCrmUserId = () => import_browser_polyfill.default.storage.local.get("crmUserId").then((data) => data.crmUserId || data.username);
	var getCrmApiUrl = () => import_browser_polyfill.default.storage.local.get("crmApiUrl").then((data) => data.crmApiUrl || "https://crm-api.securedapp.io/api/activity");
	//#endregion
	//#region src/background/helpers.ts
	var getTab = (id) => import_browser_polyfill.default.tabs.get(id);
	var getTabs = (query = {}) => import_browser_polyfill.default.tabs.query(query);
	var getActiveWindowTab = async () => {
		const tabs = await getTabs({
			active: true,
			currentWindow: true
		});
		if (tabs.length > 0) return tabs[0];
		console.debug("No active tab found in current window");
		const allTabs = await getTabs({ active: true });
		if (allTabs.length > 0) return allTabs[0];
		console.debug("No active tab found in any window");
	};
	var getBrowser = async () => {
		const storedName = await getBrowserName();
		if (storedName) return storedName;
		const browserName = detectBrowser();
		await setBrowserName(browserName);
		return browserName;
	};
	var detectBrowser = () => {
		if (navigator.brave?.isBrave()) return "brave";
		else if (navigator.userAgent.includes("Opera") || navigator.userAgent.includes("OPR")) return "opera";
		else if (navigator.userAgent.includes("Firefox")) return "firefox";
		else if (navigator.userAgent.includes("Chrome")) return "chrome";
		else if (navigator.userAgent.includes("Safari")) return "safari";
		else return "unknown";
	};
	//#endregion
	//#region src/background/crmClient.ts
	function extractDomain(urlStr) {
		if (!urlStr) return "";
		try {
			const formattedUrl = urlStr.startsWith("http") ? urlStr : `https://${urlStr}`;
			return new URL(formattedUrl).hostname.replace(/^www\./, "");
		} catch {
			return urlStr.split("/")[0].replace(/^www\./, "");
		}
	}
	async function fetchCrmAllowedDomains() {
		try {
			const baseUrl = await getCrmApiUrl() || "https://crm-api.securedapp.io/api/activity";
			const res = await fetch(`${baseUrl}/allowed-domains`, {
				method: "GET",
				headers: { "Content-Type": "application/json" }
			});
			if (!res.ok) return null;
			return await res.json();
		} catch (err) {
			console.debug("CRM allowed-domains fetch offline or failed:", err);
			return null;
		}
	}
	function isDomainAllowedByCrm(urlStr, allowedDomainsData) {
		if (!allowedDomainsData || !allowedDomainsData.strictAllowlistOnly) return true;
		const cleanDomain = extractDomain(urlStr).toLowerCase();
		const cleanUrl = (urlStr || "").toLowerCase();
		if (cleanUrl.startsWith("chrome://") || cleanUrl.startsWith("chrome-extension://") || cleanUrl.startsWith("about:") || cleanUrl.startsWith("edge://")) return cleanDomain === "extension-disabled";
		if (cleanDomain === "localhost" || cleanDomain === "127.0.0.1") return true;
		return allowedDomainsData.allowedDomains.some((rule) => {
			if (!rule.isActive) return false;
			const pattern = (rule.domainPattern || "").trim().toLowerCase();
			if (pattern.startsWith("*.")) {
				const base = pattern.replace("*.", "");
				return cleanDomain.endsWith(base) || cleanDomain === base;
			} else if (pattern.includes("*")) {
				const regex = new RegExp("^" + pattern.replace(/\*/g, ".*") + "$", "i");
				return regex.test(cleanDomain) || regex.test(cleanUrl);
			}
			return cleanDomain === pattern || cleanDomain.endsWith("." + pattern) || cleanUrl.includes(pattern);
		});
	}
	async function sendCrmActivityBatch(activities, browserName, deviceId) {
		if (!activities || activities.length === 0) return false;
		const userId = await getCrmUserId() || "Default-User";
		const baseUrl = await getCrmApiUrl() || "https://crm-api.securedapp.io/api/activity";
		try {
			const payload = {
				userId,
				browserName,
				deviceId,
				timezoneOffset: (/* @__PURE__ */ new Date()).getTimezoneOffset(),
				activities
			};
			const res = await fetch(`${baseUrl}/log`, {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify(payload)
			});
			if (res.ok) {
				const data = await res.json();
				console.info(`Successfully synced ${data.count || activities.length} items to CRM Admin backend`);
				return true;
			} else {
				console.warn(`CRM Sync HTTP error: ${res.status}`);
				return false;
			}
		} catch (err) {
			console.debug("CRM Sync failed (backend offline or unreachable):", err);
			return false;
		}
	}
	//#endregion
	//#region src/background/heartbeat.ts
	var isSystemIdle = false;
	var currentSessionStart = /* @__PURE__ */ new Date();
	function setSystemIdleState(idle) {
		isSystemIdle = idle;
	}
	var idleStateChangeListener = (state) => {
		console.info("Browser idle state changed:", state);
		setSystemIdleState(state !== "active");
	};
	async function heartbeat(_client, tab, tabCount) {
		if (!await getEnabled()) {
			console.warn("Ignoring heartbeat because client has not been enabled");
			return;
		}
		if (!tab) {
			console.warn("Ignoring heartbeat because no active tab was found");
			return;
		}
		if (!tab.url || !tab.title) {
			console.warn("Ignoring heartbeat because tab is missing URL or title");
			return;
		}
		const { url, title, audible, incognito } = tab;
		const now = /* @__PURE__ */ new Date();
		const rawDuration = Math.round((now.getTime() - currentSessionStart.getTime()) / 1e3);
		const durationSeconds = Math.min(300, Math.max(1, rawDuration));
		currentSessionStart = now;
		const domain = extractDomain(url);
		if (isDomainAllowedByCrm(url, await fetchCrmAllowedDomains())) {
			const crmActivityItem = {
				url,
				domain,
				pageTitle: title,
				startTime: (/* @__PURE__ */ new Date(now.getTime() - durationSeconds * 1e3)).toISOString(),
				endTime: now.toISOString(),
				durationSeconds,
				isIdle: isSystemIdle,
				audible: audible ?? false,
				incognito: Boolean(incognito),
				tabCount
			};
			const browserName = await getBrowser();
			const deviceId = await getHostname() || "Default-Device";
			sendCrmActivityBatch([crmActivityItem], browserName, deviceId).catch((err) => {
				console.debug("CRM activity sync failed background task:", err);
			});
		} else console.debug(`CRM Sync: URL omitted per allowlist policy: ${url}`);
	}
	var sendInitialHeartbeat = async (client) => {
		const activeWindowTab = await getActiveWindowTab();
		const tabs = await getTabs();
		console.debug("Sending initial heartbeat", activeWindowTab?.url);
		await heartbeat(client, activeWindowTab, tabs.length);
	};
	var heartbeatAlarmListener = (client) => async (alarm) => {
		if (alarm.name !== config.heartbeat.alarmName) return;
		const activeWindowTab = await getActiveWindowTab();
		if (!activeWindowTab) return;
		const tabs = await getTabs();
		console.debug("Sending heartbeat for alarm", activeWindowTab.url);
		await heartbeat(client, activeWindowTab, tabs.length);
	};
	var tabActivatedListener = (client) => async (activeInfo) => {
		const tab = await getTab(activeInfo.tabId);
		const tabs = await getTabs();
		console.debug("Sending heartbeat for tab activation", tab.url);
		await heartbeat(client, tab, tabs.length);
	};
	var tabUpdatedListener = (client) => async (_tabId, changeInfo, tab) => {
		if (!changeInfo.url && !changeInfo.title && changeInfo.status !== "complete") return;
		if (!tab.active) return;
		const tabs = await getTabs();
		console.debug("Sending heartbeat for tab update", tab.url);
		await heartbeat(client, tab, tabs.length);
	};
	var windowFocusChangedListener = (client) => async (windowId) => {
		if (windowId === import_browser_polyfill.default.windows.WINDOW_ID_NONE) return;
		const tabs = await getTabs({
			active: true,
			windowId
		});
		if (tabs.length === 0) return;
		const allTabs = await getTabs();
		console.debug("Sending heartbeat for window focus change", tabs[0].url);
		await heartbeat(client, tabs[0], allTabs.length);
	};
	//#endregion
	//#region src/background/client.ts
	var getClient = () => new import_aw_client.AWClient("aw-client-web", {
		testing: config.isDevelopment,
		baseURL: void 0
	});
	async function detectHostname(_client) {
		const existing = await getHostname();
		if (existing) return existing;
		return "Client-Device";
	}
	//#endregion
	//#region src/background/main.ts
	async function getIsConsentRequired() {
		if (!config.requireConsent) return false;
		return import_browser_polyfill.default.storage.managed.get("consentOfflineDataCollection").then((consentOfflineDataCollection) => !consentOfflineDataCollection).catch(() => true);
	}
	async function autodetectHostname() {
		if (await getHostname() === void 0) {
			const detectedHostname = await detectHostname(client);
			if (detectedHostname !== void 0) setHostname(detectedHostname);
		}
	}
	/** Init */
	console.info("Starting...");
	console.debug("Creating client");
	var client = getClient();
	import_browser_polyfill.default.runtime.onInstalled.addListener(async () => {
		const { consent } = await getConsentStatus();
		const isConsentRequired = await getIsConsentRequired();
		if (!isConsentRequired || consent) {
			if (!isConsentRequired) console.info("Consent is not required");
			else if (consent) console.info("Consent required but already accepted");
			console.debug("Enabling the extension");
			await setEnabled(true);
		} else {
			console.info("Consent is required...opening consent tab");
			await setConsentStatus({
				consent,
				required: true
			});
			await import_browser_polyfill.default.tabs.create({
				active: true,
				url: import_browser_polyfill.default.runtime.getURL("src/consent/index.html")
			});
		}
		await autodetectHostname();
	});
	console.debug("Creating alarms, idle, and tab listeners");
	if (import_browser_polyfill.default.idle) {
		import_browser_polyfill.default.idle.setDetectionInterval(60);
		import_browser_polyfill.default.idle.onStateChanged.addListener(idleStateChangeListener);
	}
	import_browser_polyfill.default.alarms.create(config.heartbeat.alarmName, { periodInMinutes: Math.floor(config.heartbeat.intervalInSeconds / 60) });
	import_browser_polyfill.default.alarms.onAlarm.addListener(heartbeatAlarmListener(client));
	import_browser_polyfill.default.tabs.onActivated.addListener(tabActivatedListener(client));
	import_browser_polyfill.default.tabs.onUpdated.addListener(tabUpdatedListener(client));
	import_browser_polyfill.default.windows.onFocusChanged.addListener(windowFocusChangedListener(client));
	console.debug("Setting base url");
	setBaseUrl(client.baseURL).then(() => console.debug("Waiting for enable before sending initial heartbeat")).then(waitForEnabled).then(() => sendInitialHeartbeat(client)).then(() => console.info("Started successfully"));
	/**
	* Keep the service worker alive using Offscreen API to prevent Chrome's termination.
	*/
	async function setupOffscreen() {
		const _chrome = globalThis.chrome;
		if (typeof _chrome === "undefined" || !_chrome.offscreen) return;
		if (await _chrome.offscreen.hasDocument()) return;
		try {
			await _chrome.offscreen.createDocument({
				url: "offscreen.html",
				reasons: ["BLOBS"],
				justification: "Keep service worker alive for heartbeat packets"
			});
		} catch (e) {
			console.error("Failed to create offscreen document:", e);
		}
	}
	import_browser_polyfill.default.runtime.onMessage.addListener((message) => {
		if (message.type === "KEEP_ALIVE") return Promise.resolve({ status: "ok" });
	});
	import_browser_polyfill.default.runtime.onStartup.addListener(setupOffscreen);
	import_browser_polyfill.default.runtime.onInstalled.addListener(setupOffscreen);
	setupOffscreen();
	//#endregion
})();
