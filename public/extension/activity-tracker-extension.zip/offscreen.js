// Keep the service worker alive by pinging it every 20 seconds.
// Offscreen documents only support the chrome.runtime API, so this is a plain
// classic script (no ES modules, no webextension-polyfill).
function keepAlive() {
  chrome.runtime.sendMessage({ type: 'KEEP_ALIVE' }).catch(() => {
    // Expected during reload
  })
}

setInterval(keepAlive, 20 * 1000)
keepAlive()
