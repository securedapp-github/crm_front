import { _ as require_browser_polyfill, a as getCrmUserId, c as getUsername, g as setUsername, m as setEnabled, n as getConsentStatus, o as getEnabled, p as setCrmUserId, y as __toESM } from "../../storage.js";
import { n as sendCrmOfflineSignal } from "../../crmClient.js";
//#region src/config.ts
var import_browser_polyfill = /* @__PURE__ */ __toESM(require_browser_polyfill(), 1);
var config = {
	isDevelopment: false,
	requireConsent: false,
	heartbeat: {
		alarmName: "heartbeat",
		intervalInSeconds: 60
	}
};
//#endregion
//#region src/popup/main.ts
function updateStatusText(enabled) {
	const statusText = document.getElementById("status-text");
	if (statusText) {
		statusText.innerText = enabled ? "Status: On" : "Status: Off";
		statusText.style.color = enabled ? "#10b981" : "#6b7280";
	}
}
async function renderStatus() {
	const enabled = await getEnabled();
	const username = await getCrmUserId() || await getUsername();
	const consentStatus = await getConsentStatus();
	const enabledToggle = document.getElementById("status-enabled-toggle");
	if (enabledToggle instanceof HTMLInputElement) {
		enabledToggle.checked = enabled;
		updateStatusText(enabled);
	}
	const usernameInput = document.getElementById("username-input");
	if (usernameInput instanceof HTMLInputElement && username !== void 0) usernameInput.value = username;
	const showConsentBtn = document.getElementById("status-consent-btn");
	if (showConsentBtn instanceof HTMLButtonElement) if (!consentStatus.required || consentStatus.consent) {
		enabledToggle?.removeAttribute("disabled");
		showConsentBtn.style.display = "none";
	} else {
		enabledToggle?.setAttribute("disabled", "");
		showConsentBtn.style.display = "block";
	}
	if (config.isDevelopment) {
		const element = document.getElementById("testing-notice");
		if (element) {
			element.innerText = "Extension is running in testing mode";
			element.style.display = "block";
		}
	}
}
function domListeners() {
	const enabledToggle = document.getElementById("status-enabled-toggle");
	if (enabledToggle instanceof HTMLInputElement) enabledToggle.addEventListener("change", async () => {
		const enabled = enabledToggle.checked;
		updateStatusText(enabled);
		await setEnabled(enabled);
		if (!enabled) sendCrmOfflineSignal().catch((err) => console.debug("Offline signal error:", err));
	});
	const usernameInput = document.getElementById("username-input");
	const saveStatus = document.getElementById("username-save-status");
	if (usernameInput instanceof HTMLInputElement) {
		let timeoutId;
		usernameInput.addEventListener("input", () => {
			if (timeoutId) clearTimeout(timeoutId);
			timeoutId = window.setTimeout(async () => {
				await setUsername(usernameInput.value);
				await setCrmUserId(usernameInput.value);
				if (saveStatus) {
					saveStatus.style.opacity = "1";
					setTimeout(() => {
						saveStatus.style.opacity = "0";
					}, 1500);
				}
			}, 400);
		});
	}
	const consentButton = document.getElementById("status-consent-btn");
	if (consentButton instanceof HTMLButtonElement) consentButton.addEventListener("click", () => {
		import_browser_polyfill.default.tabs.create({
			active: true,
			url: import_browser_polyfill.default.runtime.getURL("src/consent/index.html")
		});
	});
	const settingsButton = document.getElementById("settings-btn");
	if (settingsButton instanceof HTMLAnchorElement) settingsButton.addEventListener("click", (e) => {
		e.preventDefault();
		import_browser_polyfill.default.runtime.openOptionsPage();
	});
}
renderStatus();
domListeners();
//#endregion
