import { a as getCrmUserId, f as setCrmToken, i as getCrmToken, p as setCrmUserId, r as getCrmApiUrl } from "./storage.js";
//#region src/background/crmClient.ts
async function sendCrmActivityBatch(activities, browserName, deviceId) {
	if (!activities || activities.length === 0) return false;
	const userId = await getCrmUserId() || "Default-User";
	const baseUrl = await getCrmApiUrl() || "https://crm-be.securedapp.io/api/activity";
	try {
		const payload = {
			userId,
			browserName,
			deviceId,
			timezoneOffset: (/* @__PURE__ */ new Date()).getTimezoneOffset(),
			activities
		};
		const token = await getCrmToken();
		const headers = { "Content-Type": "application/json" };
		if (token) headers["Authorization"] = `Bearer ${token}`;
		const res = await fetch(`${baseUrl}/log`, {
			method: "POST",
			headers,
			body: JSON.stringify(payload)
		});
		if (res.ok) {
			const data = await res.json();
			console.info(`Successfully synced ${data.count || activities.length} items to CRM Admin backend`);
			return true;
		} else {
			console.warn(`CRM Sync HTTP error: ${res.status}`);
			return false;
		}
	} catch (err) {
		console.debug("CRM Sync failed (backend offline or unreachable):", err);
		return false;
	}
}
async function sendCrmOfflineSignal() {
	return sendCrmActivityBatch([{
		url: "chrome://extension-turned-off",
		domain: "extension-disabled",
		pageTitle: "Extension Turned Off",
		startTime: (/* @__PURE__ */ new Date()).toISOString(),
		endTime: (/* @__PURE__ */ new Date()).toISOString(),
		durationSeconds: 0,
		isIdle: true
	}], "Chrome", "Device-Default");
}
async function extensionLogin(email, password, crmApiUrl) {
	try {
		const authUrl = (crmApiUrl || await getCrmApiUrl() || "https://crm-be.securedapp.io/api/activity").replace(/\/activity\/?$/, "/auth/extension-login");
		const res = await fetch(authUrl, {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({
				email,
				password
			})
		});
		const data = await res.json();
		if (res.ok && data.success && data.token) {
			await setCrmToken(data.token);
			if (data.userId) await setCrmUserId(data.userId);
			return { success: true };
		} else return {
			success: false,
			error: data.error || data.message || "Authentication failed"
		};
	} catch (err) {
		return {
			success: false,
			error: err?.message || "Network error connecting to CRM backend"
		};
	}
}
//#endregion
export { sendCrmOfflineSignal as n, extensionLogin as t };
