import { _ as require_browser_polyfill, d as setCrmApiUrl, h as setHostname, i as getCrmToken, l as setBrowserName, r as getCrmApiUrl, s as getHostname, t as getBrowserName, v as __commonJSMin, y as __toESM } from "../../storage.js";
import { t as extensionLogin } from "../../crmClient.js";
//#region node_modules/aw-client/out/aw-client.js
var require_aw_client = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __awaiter = exports && exports.__awaiter || function(thisArg, _arguments, P, generator) {
		function adopt(value) {
			return value instanceof P ? value : new P(function(resolve) {
				resolve(value);
			});
		}
		return new (P || (P = Promise))(function(resolve, reject) {
			function fulfilled(value) {
				try {
					step(generator.next(value));
				} catch (e) {
					reject(e);
				}
			}
			function rejected(value) {
				try {
					step(generator["throw"](value));
				} catch (e) {
					reject(e);
				}
			}
			function step(result) {
				result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
			}
			step((generator = generator.apply(thisArg, _arguments || [])).next());
		});
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.AWClient = exports.FetchError = void 0;
	var FetchError = class extends Error {
		constructor(res) {
			super(`Failed fetch with status code ${res.status}`);
			this.response = res;
		}
	};
	exports.FetchError = FetchError;
	function makeTimeoutAbortSignal(timeout, existingSignal) {
		if (timeout === void 0) return {
			signal: existingSignal,
			timeoutId: void 0
		};
		const abortController = new AbortController();
		const timeoutId = setTimeout(() => abortController.abort(), timeout || 1e4);
		if (existingSignal === null || existingSignal === void 0 ? void 0 : existingSignal.aborted) abortController.abort();
		else existingSignal === null || existingSignal === void 0 || existingSignal.addEventListener("abort", () => abortController.abort());
		return {
			signal: abortController.signal,
			timeoutId
		};
	}
	function fetchWithFailure(input, init, timeout) {
		return __awaiter(this, void 0, void 0, function* () {
			const { signal, timeoutId } = makeTimeoutAbortSignal(timeout, init.signal || void 0);
			return fetch(input, Object.assign(Object.assign({}, init), { signal })).then((res) => {
				if (res.status >= 300) throw new FetchError(res);
				return res;
			}).finally(() => clearTimeout(timeoutId));
		});
	}
	var AWClient = class {
		constructor(clientname, options = {}) {
			var _a, _b;
			this.heartbeatQueues = {};
			this.clientname = clientname;
			this.testing = (_a = options.testing) !== null && _a !== void 0 ? _a : false;
			this.timeout = (_b = options.timeout) !== null && _b !== void 0 ? _b : 3e4;
			if (typeof options.baseURL === "undefined") {
				const port = !options.testing ? 5600 : 5666;
				this.baseURL = `http://127.0.0.1:${port}`;
			} else this.baseURL = options.baseURL;
			this.apiURL = this.baseURL + "/api";
			this.controller = options.controller || new AbortController();
			this.queryCache = {};
		}
		/** Makes a GET request, assuming the response is JSON and parsing it */
		_get(endpoint_1) {
			return __awaiter(this, arguments, void 0, function* (endpoint, params = {}) {
				return fetchWithFailure(`${this.apiURL}${endpoint}`, Object.assign(Object.assign({}, params), { signal: this.controller.signal }), this.timeout).then((res) => res.json());
			});
		}
		_post(endpoint, data) {
			return __awaiter(this, void 0, void 0, function* () {
				return fetchWithFailure(`${this.apiURL}${endpoint}`, {
					method: "POST",
					signal: this.controller.signal,
					headers: { "Content-Type": "application/json" },
					body: JSON.stringify(data)
				}, this.timeout);
			});
		}
		_delete(endpoint) {
			return __awaiter(this, void 0, void 0, function* () {
				return fetchWithFailure(`${this.apiURL}${endpoint}`, {
					method: "DELETE",
					signal: this.controller.signal
				}, this.timeout);
			});
		}
		getInfo() {
			return __awaiter(this, void 0, void 0, function* () {
				return this._get("/0/info");
			});
		}
		abort(msg) {
			return __awaiter(this, void 0, void 0, function* () {
				console.info(msg || "Requests cancelled");
				this.controller.abort();
				this.controller = new AbortController();
			});
		}
		processRawBucket(bucket) {
			return Object.assign(Object.assign({}, bucket), {
				created: new Date(bucket.created),
				last_update: bucket.last_update !== void 0 ? new Date(bucket.last_update) : void 0
			});
		}
		ensureBucket(bucketId, type, hostname) {
			return __awaiter(this, void 0, void 0, function* () {
				return this._post(`/0/buckets/${bucketId}`, {
					client: this.clientname,
					type,
					hostname
				}).then(() => ({ alreadyExist: false })).catch((err) => {
					if (err instanceof FetchError && err.response.status === 304) return { alreadyExist: true };
					throw err;
				});
			});
		}
		createBucket(bucketId, type, hostname) {
			return __awaiter(this, void 0, void 0, function* () {
				yield this._post(`/0/buckets/${bucketId}`, {
					client: this.clientname,
					type,
					hostname
				});
			});
		}
		deleteBucket(bucketId) {
			return __awaiter(this, void 0, void 0, function* () {
				yield this._delete(`/0/buckets/${bucketId}?force=1`);
			});
		}
		getBuckets() {
			return __awaiter(this, void 0, void 0, function* () {
				const rawBuckets = yield this._get("/0/buckets/");
				const buckets = {};
				for (const bucketId of Object.keys(rawBuckets)) buckets[bucketId] = this.processRawBucket(rawBuckets[bucketId]);
				return buckets;
			});
		}
		getBucketInfo(bucketId) {
			return __awaiter(this, void 0, void 0, function* () {
				const bucket = yield this._get(`/0/buckets/${bucketId}`);
				if (bucket.data === void 0) {
					console.warn("Received bucket had undefined data, likely due to data field unsupported by server. Try updating your ActivityWatch server to get rid of this message.");
					bucket.data = {};
				}
				return this.processRawBucket(bucket);
			});
		}
		processRawEvent(event) {
			return Object.assign(Object.assign({}, event), { timestamp: new Date(event.timestamp) });
		}
		/** Get a single event by ID */
		getEvent(bucketId, eventId) {
			return __awaiter(this, void 0, void 0, function* () {
				return this._get(`/0/buckets/${bucketId}/events/${eventId}`).then(this.processRawEvent);
			});
		}
		/** Get events, with optional date ranges and limit */
		getEvents(bucketId_1) {
			return __awaiter(this, arguments, void 0, function* (bucketId, params = {}) {
				const searchParams = new URLSearchParams();
				if (params.start) searchParams.set("start", params.start.toISOString());
				if (params.end) searchParams.set("end", params.end.toISOString());
				if (params.limit) searchParams.set("limit", params.limit.toString());
				const url = `/0/buckets/${bucketId}/events?${searchParams.toString()}`;
				return this._get(url).then((events) => events.map(this.processRawEvent));
			});
		}
		/** Count the number of events, with optional date ranges */
		countEvents(bucketId, startTime, endTime) {
			return __awaiter(this, void 0, void 0, function* () {
				const params = new URLSearchParams();
				if (startTime) params.set("start", startTime.toISOString());
				if (endTime) params.set("end", endTime.toISOString());
				const url = `/0/buckets/${bucketId}/events/count?${params.toString()}`;
				return this._get(url);
			});
		}
		/** Insert a single event, requires the event to not have an ID assigned */
		insertEvent(bucketId, event) {
			return __awaiter(this, void 0, void 0, function* () {
				yield this.insertEvents(bucketId, [event]);
			});
		}
		/** Insert multiple events, requires the events to not have IDs assigned */
		insertEvents(bucketId, events) {
			return __awaiter(this, void 0, void 0, function* () {
				for (const event of events) if (event.id !== void 0) throw Error(`Can't insert event with ID assigned: ${event}`);
				yield this._post("/0/buckets/" + bucketId + "/events", events);
			});
		}
		/** Replace an event, requires the event to have an ID assigned */
		replaceEvent(bucketId, event) {
			return __awaiter(this, void 0, void 0, function* () {
				yield this.replaceEvents(bucketId, [event]);
			});
		}
		/** Replace multiple events, requires the events to have IDs assigned */
		replaceEvents(bucketId, events) {
			return __awaiter(this, void 0, void 0, function* () {
				for (const event of events) if (event.id === void 0) throw Error("Can't replace event without ID assigned");
				yield this._post("/0/buckets/" + bucketId + "/events", events);
			});
		}
		/** Delete an event by ID */
		deleteEvent(bucketId, eventId) {
			return __awaiter(this, void 0, void 0, function* () {
				yield this._delete("/0/buckets/" + bucketId + "/events/" + eventId);
			});
		}
		/**
		* @param bucketId The id of the bucket to send the heartbeat to
		* @param pulsetime The maximum amount of time in seconds since the last heartbeat to be merged
		*                  with the previous heartbeat in aw-server
		* @param heartbeat The actual heartbeat event
		*/
		heartbeat(bucketId, pulsetime, heartbeat) {
			var _a;
			var _b;
			(_a = (_b = this.heartbeatQueues)[bucketId]) !== null && _a !== void 0 || (_b[bucketId] = {
				isProcessing: false,
				data: []
			});
			return new Promise((resolve, reject) => {
				this.heartbeatQueues[bucketId].data.push({
					onSuccess: resolve,
					onError: reject,
					pulsetime,
					heartbeat
				});
				this.updateHeartbeatQueue(bucketId);
			});
		}
		/**
		* Queries the aw-server for data
		*
		* If cache is enabled, for each {query, timeperiod} it will return cached data if available,
		* if a timeperiod spans the future it will not cache it.
		*/
		query(timeperiods_1, query_1) {
			return __awaiter(this, arguments, void 0, function* (timeperiods, query, params = {}) {
				var _a, _b, _c, _d;
				params.cache = (_a = params.cache) !== null && _a !== void 0 ? _a : true;
				params.cacheEmpty = (_b = params.cacheEmpty) !== null && _b !== void 0 ? _b : false;
				params.verbose = (_c = params.verbose) !== null && _c !== void 0 ? _c : false;
				params.name = (_d = params.name) !== null && _d !== void 0 ? _d : "query";
				function isEmpty(obj) {
					return Object.keys(obj).length === 0;
				}
				const data = {
					query,
					timeperiods: timeperiods.map((tp) => typeof tp !== "string" ? `${tp.start.toISOString()}/${tp.end.toISOString()}` : tp)
				};
				const cacheResults = [];
				if (params.cache) {
					for (const timeperiod of data.timeperiods) {
						const stop = new Date(timeperiod.split("/")[1]);
						if (/* @__PURE__ */ new Date() < stop) {
							cacheResults.push(null);
							continue;
						}
						const cacheKey = JSON.stringify({
							timeperiod,
							query
						});
						if (this.queryCache[cacheKey] && (params.cacheEmpty || !isEmpty(this.queryCache[cacheKey]))) cacheResults.push(this.queryCache[cacheKey]);
						else cacheResults.push(null);
					}
					if (cacheResults.every((r) => r !== null)) {
						if (params.verbose) console.debug(`Returning fully cached query results for ${params.name}`);
						return cacheResults;
					}
				}
				const timeperiodsNotCached = data.timeperiods.filter((_, i) => cacheResults[i] === null);
				const queryResults = timeperiodsNotCached.length > 0 ? yield this._post("/0/query/", Object.assign(Object.assign({}, data), { timeperiods: timeperiodsNotCached })).then((res) => res.json()) : [];
				if (!params.cache) return queryResults;
				if (params.verbose) {
					if (cacheResults.every((r) => r === null)) console.debug(`Returning uncached query results for ${params.name}`);
					else if (cacheResults.some((r) => r === null) && cacheResults.some((r) => r !== null)) console.debug(`Returning partially cached query results for ${params.name}`);
				}
				for (const [i, result] of queryResults.entries()) {
					const cacheKey = JSON.stringify({
						timeperiod: timeperiodsNotCached[i],
						query
					});
					this.queryCache[cacheKey] = result;
				}
				return data.timeperiods.map((tp) => {
					const cacheKey = JSON.stringify({
						timeperiod: tp,
						query
					});
					return this.queryCache[cacheKey];
				});
			});
		}
		send_heartbeat(bucketId, pulsetime, data) {
			return __awaiter(this, void 0, void 0, function* () {
				const url = "/0/buckets/" + bucketId + "/heartbeat?pulsetime=" + pulsetime;
				const heartbeat = yield this._post(url, data).then((res) => res.json());
				heartbeat.timestamp = new Date(heartbeat.timestamp);
				return heartbeat;
			});
		}
		/** Start heartbeat queue processing if not currently processing */
		updateHeartbeatQueue(bucketId) {
			const queue = this.heartbeatQueues[bucketId];
			if (queue.isProcessing || !queue.data.length) return;
			const { pulsetime, heartbeat, onSuccess, onError } = queue.data.shift();
			queue.isProcessing = true;
			this.send_heartbeat(bucketId, pulsetime, heartbeat).then(() => {
				onSuccess();
				queue.isProcessing = false;
				this.updateHeartbeatQueue(bucketId);
			}).catch((err) => {
				onError(err);
				queue.isProcessing = false;
				this.updateHeartbeatQueue(bucketId);
			});
		}
		get_settings() {
			return __awaiter(this, void 0, void 0, function* () {
				return yield this._get("/0/settings");
			});
		}
		get_setting(key) {
			return __awaiter(this, void 0, void 0, function* () {
				return yield this._get("/0/settings/" + key);
			});
		}
		set_setting(key, value) {
			return __awaiter(this, void 0, void 0, function* () {
				yield this._post("/0/settings/" + key, value);
			});
		}
	};
	exports.AWClient = AWClient;
}));
//#endregion
//#region src/background/helpers.ts
var import_browser_polyfill = /* @__PURE__ */ __toESM(require_browser_polyfill(), 1);
require_aw_client();
var detectBrowser = () => {
	if (navigator.brave?.isBrave()) return "brave";
	else if (navigator.userAgent.includes("Opera") || navigator.userAgent.includes("OPR")) return "opera";
	else if (navigator.userAgent.includes("Firefox")) return "firefox";
	else if (navigator.userAgent.includes("Chrome")) return "chrome";
	else if (navigator.userAgent.includes("Safari")) return "safari";
	else return "unknown";
};
//#endregion
//#region src/settings/main.ts
async function reloadExtension() {
	import_browser_polyfill.default.runtime.reload();
	if (detectBrowser() !== "firefox") window.close();
}
async function saveOptions(e) {
	e.preventDefault();
	const browserSelect = document.querySelector("#browser");
	const customBrowserInput = document.querySelector("#customBrowser");
	if (!browserSelect) return;
	let selectedBrowser = browserSelect.value;
	if (selectedBrowser === "other" && customBrowserInput?.value) selectedBrowser = customBrowserInput.value.toLowerCase();
	const hostnameInput = document.querySelector("#hostname");
	if (!hostnameInput) return;
	const hostname = hostnameInput.value;
	const crmApiUrlInput = document.querySelector("#crmApiUrl");
	const crmEmailInput = document.querySelector("#crmEmail");
	const crmPasswordInput = document.querySelector("#crmPassword");
	const crmStatusMsg = document.querySelector("#crmStatusMsg");
	const button = e.target.querySelector("button");
	if (!button) return;
	button.textContent = "Saving...";
	button.classList.remove("accept");
	try {
		await setBrowserName(selectedBrowser);
		await setHostname(hostname);
		if (crmApiUrlInput && crmApiUrlInput.value) await setCrmApiUrl(crmApiUrlInput.value.trim());
		if (crmEmailInput && crmPasswordInput && crmEmailInput.value && crmPasswordInput.value) {
			const authRes = await extensionLogin(crmEmailInput.value.trim(), crmPasswordInput.value, crmApiUrlInput?.value?.trim());
			if (!authRes.success) {
				if (crmStatusMsg) {
					crmStatusMsg.style.display = "block";
					crmStatusMsg.style.color = "#ef4444";
					crmStatusMsg.textContent = "CRM Login Failed: " + authRes.error;
				}
			} else if (crmStatusMsg) {
				crmStatusMsg.style.display = "block";
				crmStatusMsg.style.color = "#10b981";
				crmStatusMsg.textContent = "✓ Successfully authenticated with CRM backend!";
			}
		}
		await reloadExtension();
		button.textContent = "Save";
		button.classList.add("accept");
	} catch (error) {
		console.error("Failed to save options:", error);
		button.textContent = "Error";
		button.classList.add("error");
	}
}
function toggleCustomBrowserInput() {
	const browserSelect = document.querySelector("#browser");
	const customInput = document.querySelector("#customBrowser");
	if (browserSelect && customInput) {
		const isOther = browserSelect.value === "other";
		customInput.style.display = isOther ? "block" : "none";
		customInput.required = isOther;
	}
}
async function restoreOptions() {
	try {
		const browserName = await getBrowserName();
		const browserSelect = document.querySelector("#browser");
		const customInput = document.querySelector("#customBrowser");
		if (!browserSelect || !customInput || !browserName) return;
		if (!Array.from(browserSelect.options).map((opt) => opt.value).includes(browserName)) {
			browserSelect.value = "other";
			customInput.style.display = "block";
			customInput.value = browserName;
			customInput.required = true;
		} else {
			browserSelect.value = browserName;
			customInput.style.display = "none";
			customInput.required = false;
		}
		const crmApiUrl = await getCrmApiUrl();
		const crmApiUrlInput = document.querySelector("#crmApiUrl");
		if (crmApiUrlInput && crmApiUrl) crmApiUrlInput.value = crmApiUrl;
		const crmToken = await getCrmToken();
		const crmStatusMsg = document.querySelector("#crmStatusMsg");
		if (crmStatusMsg && crmToken) {
			crmStatusMsg.style.display = "block";
			crmStatusMsg.style.color = "#10b981";
			crmStatusMsg.textContent = "✓ Extension is connected to CRM backend";
		}
		const hostname = await getHostname();
		const hostnameInput = document.querySelector("#hostname");
		if (!hostnameInput) return;
		if (hostname !== void 0) hostnameInput.value = hostname;
	} catch (error) {
		console.error("Failed to restore options:", error);
	}
}
document.addEventListener("DOMContentLoaded", () => {
	restoreOptions();
	toggleCustomBrowserInput();
});
document.querySelector("#browser")?.addEventListener("change", toggleCustomBrowserInput);
var form = document.querySelector("form");
if (form) form.addEventListener("submit", (e) => {
	e.preventDefault();
	saveOptions(e);
});
//#endregion
